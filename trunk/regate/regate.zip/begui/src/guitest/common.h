#pragma once

#include "../../include/bgui.h"

using namespace begui;
